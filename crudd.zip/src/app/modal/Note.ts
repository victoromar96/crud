export interface Note {
    id?: any;
    title: string;
    content: string;
    createdAt: any;
}
